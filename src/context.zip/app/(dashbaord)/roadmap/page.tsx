import { createClient } from "@/lib/supabase/server";
import { getPersonalizedRoadmap } from "@/lib/services/roadmap";
import { db } from "@/lib/db";
import { profiles } from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";

export default async function RoadmapPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const [profile] = await db
    .select()
    .from(profiles)
    .where(eq(profiles.id, user.id));

  if (!profile?.onboardingCompleted) {
    redirect("/onboarding");
  }

  const roadmap = await getPersonalizedRoadmap(user.id);

  return <div className="p-6">roadmap</div>;
}
