import { getPersonalizedRoadmap } from "@/lib/services/roadmap";

export default async function TestPage() {
  const userId = "07a68550-c44e-4f0d-a1c2-7e536f45c5d9"; // replace this

  const roadmap = await getPersonalizedRoadmap(userId);

  console.log("ROADMAP:", roadmap);

  return (
    <div>
      <h1>Check terminal for roadmap output</h1>
      <pre>{JSON.stringify(roadmap, null, 2)}</pre>
    </div>
  );
}
